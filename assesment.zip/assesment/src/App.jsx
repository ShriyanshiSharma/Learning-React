import React from "react";
import GetDetails from "./component/GetDetails";
import './component/style.css';

const App = () => {
    return (
        <>
        <GetDetails/> 
        </>
    );
};

export default App;